#include <iostream>
#include <vector>
using namespace std;

// abstract class
class Persona{
    string nombre;
public:
    Persona(string nombre): nombre(nombre){}
    virtual void foo() = 0;
    virtual int getTipo() = 0;
    string getNombre(){
        return nombre;
    }
    virtual void print(ostream &out) = 0;
    friend ostream& operator<<(ostream &out, Persona* persona){
        out << "Nombre: " << persona->nombre << endl;
        persona->print(out);
        return out;
    }
};
class Paciente: public Persona{
    string diagnostico;
public:
    Paciente(string nombre, string diagnostico): Persona(nombre), diagnostico(diagnostico){}
    void foo() override{
        cout << "Soy paciente" << endl;
    }
    int getTipo() override{
        return 0;
    }
    void print(ostream& out) override{
        out << "Diagnostico: " << diagnostico;
    }
    string getDiagnostico(){
        return diagnostico;
    }
};
class Profesional: public Persona{
    string profesion;
public:
    Profesional(string nombre, string profesion): Persona(nombre), profesion(profesion){}
    void foo() override{
        cout << "Soy profesional de la salud" << endl;
    }
    int getTipo() override{
        return 1;
    }
    void print(ostream& out) override{
        out << "Profesion: " << profesion;
    }
    string getProfesion(){
        return profesion;
    }
};
class Medico: public Profesional{
    string especialidad;
public:
    Medico(string nombre, string profesion, string especialidad):
                    Profesional(nombre, profesion), especialidad(especialidad){}
    void print(ostream& out) override{
        out << "Profesion: " << getProfesion() << endl;
        out << "Especialidad: " << especialidad << endl;
    }
    int getTipo() override{
        return 2;
    }
};
int main() {
    vector<Persona*> personas = {
            new Paciente("Susana", "Diabetes")
    };
    personas.push_back(new Profesional("Juan", "Enfermería"));
    personas.push_back(new Medico("Victor", "Medicina", "Internista"));

    personas.push_back(new Paciente("Pedro", "Cefalea"));
    personas.push_back(new Profesional("Maria", "Enfermera"));

    for(Persona* persona: personas){
        if(persona->getTipo() == 0){
            cout << "Info paciente: " << endl;
            cout << persona << endl;
        }
    }

    //Paciente* paciente = (Paciente*) persona;
    //cout << "Diagnostico: " << paciente->getDiagnostico();


    return 0;
}
