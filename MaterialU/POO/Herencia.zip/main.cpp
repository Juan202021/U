#include <iostream>

using namespace std;

class Personas{
protected:
    string nombre;
    string documento;
    string correo;
public:
    Personas(){
        nombre="";
        documento="";
        correo="";
    }
    Personas(string nombre, string documento, string correo){
        Personas::nombre=nombre;
        Personas::documento=documento;
        Personas::correo=correo;
    }
    string getNombre(){
        return nombre;
    }
    string getDocumento(){
        return documento;
    }
    string getCorreo(){
        return correo;
    }

    void setNombre (string nombre){
        Personas::nombre=nombre;
    }
    void setDocumento (string documento){
        Personas::documento=documento;
    }
    void setCorreo (string correo){
        Personas::correo=correo;
    }
};

class Estudiantes : public Personas{
private:
    string codigo;
    float promedio;
public:
    Estudiantes():Personas(){
        codigo="";
        promedio=0.0;
    }
    Estudiantes(string nombre,string documento,
                string correo, string codigo,
                float promedio):Personas(nombre, documento, correo){

        Estudiantes::codigo=codigo;
        Estudiantes::promedio=promedio;
    }
    string getCodigo(){
        return codigo;
    }
    float getPromedio(){
        return promedio;
    }
    void setCodigo(string codigo){
        Estudiantes::codigo=codigo;
    }
    void setPromedio(float promedio){
        Estudiantes::promedio=promedio;
    }

};
class Docentes: public Personas{
private:
    string profesion;
public:
    Docentes():Personas(){
        profesion="";
    }
    Docentes(string nombre,string documento,string correo,string profesion):Personas(nombre,documento,correo){
        Docentes::profesion=profesion;
    }
    string getProfesion(){
      return profesion;

    };
    void setProfesion(string profesion){
        Docentes::profesion=profesion;
    }


};

int main() {
    Estudiantes e1("Quevedo","1234","h@me.co","4633",4.9);
    Docentes d1("Suat","1111","n@me.co","sistemas");
    Personas p1;
    Estudiantes e2;
    Docentes d2;
    return 0;
}
