#include <iostream>
#include <vector>
using namespace std;

class Device{
public:
    virtual void power(){
        cout << "Device powered" << endl;
    }
    virtual int getTipo() = 0;
};

class TV: public Device{
public:
    void power() override{
        cout << "TV powered" << endl;
    }
    void foo(){
        cout << "foo" << endl;
    }
    void boo(){
        cout << "boo" << endl;
    }
    int getTipo() override{
        return 0;
    }
};

class Lamp: public Device{
public:
    void power() override{
        cout << "Lamp powered" << endl;
    }
    int getTipo() override{
        return 1;
    }
};

int main() {
    /*
    Device *socket = new Device();

    socket = new Lamp();
    socket->power();

    socket = new TV();
    socket->power();

    TV* temporal = (TV*) socket;
    temporal->foo();
    temporal->boo();
    */


    vector<Device *> lista = {
            new Lamp(),
            new TV(),
    };

    lista.push_back(new TV());
    lista.push_back(new Lamp());

    lista.pop_back();

    /*for(int i=0; i<lista.size(); i++){
        if(lista[i]->getTipo() == 0){
            TV* tv_temp = (TV*) lista[i];
            tv_temp->foo();
        }
    }*/

    for(Device* l : lista ){
        if(l->getTipo() == 0){
            TV* tv_temp = (TV*) l;
            tv_temp->foo();
        }
    }


    return 0;
}
