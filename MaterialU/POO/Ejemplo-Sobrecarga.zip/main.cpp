#include <iostream>
#include <cassert>
using namespace std;

class Date{
    int month, day, year;
    int startWeekDay = 1;
    int startYear = 1900;
    static const int daysInMonths[];
    static const string  daysOfWeek[];
    static const string monthsOfYear[];

    bool isLeap(int year){
        return (year % 400 == 0) || ( (year % 4 == 0) && (year % 100 != 0) );
    }

    bool isValid(){
        bool validMonth = (month >= 1) && (month <= 12);
        bool validYear = (year >= startYear);
        bool validDay = (day >= 1) && (day <= daysInMonths[month] + (isLeap(year) && month == 2) );
        return (validMonth && validYear && validDay);
    }

    void plusReset(){
        bool extraDay = (isLeap(year) && month == 2);
        if(day > daysInMonths[month] + extraDay){
            day = 1;
            month++;
        }
        if(month > 12){
            month = 1;
            year++;
        }
    }

    void minusReset(){
        if(day < 1){
            month--;
            if(month < 1){
                month = 12;
                year--;
            }
            bool extraDay = (isLeap(year) && month == 2);
            day = daysInMonths[month] + extraDay;
        }
    }

    int findTotalDays(){
        int totalDays = 0;
        int currentYear = startYear;
        while (year > currentYear){
            totalDays += 365 + isLeap(currentYear);
            currentYear++;
        }
        int currentMonth = 1;
        while(month > currentMonth){
            totalDays += daysInMonths[currentMonth];
            if(currentMonth == 2){
                totalDays += isLeap(year);
            }
            currentMonth++;
        }
        totalDays += day - 1;
        return totalDays;
    }

public:
    Date(){
        month = 1;
        day = 1;
        year = 1900;
    }
    Date(int m, int d, int y){
        month = m;
        day = d;
        year = y;
        if (!isValid()){
            cout << "Fecha no válida; programa terminado" << endl;
            assert(false);
        }
    }

    int getMonth() const {
        return month;
    }

    void setMonth(int month) {
        Date::month = month;
    }

    int getDay() const {
        return day;
    }

    void setDay(int day) {
        Date::day = day;
    }

    int getYear() const {
        return year;
    }

    void setYear(int year) {
        Date::year = year;
    }

    Date& operator++(){
        day++;
        plusReset();
        return *this;
    }

    Date& operator++(int){
        Date temp(month, day, year);
        ++(*this);
        return temp;
    }

    Date& operator--(){
        day--;
        minusReset();
        return *this;
    }

    Date& operator--(int){
        Date temp(month, day, year);
        --(*this);
        return temp;
    }

    Date& operator+=(int days){
        for(int i=1;i<=days;i++){
            ++(*this);
        }
        return *this;
    }

    Date& operator-=(int days){
        for(int i=1;i<=days;i++){
            --(*this);
        }
        return *this;
    }

    friend int operator-(Date& date1, Date& date2){
        return ( date1.findTotalDays() - date2.findTotalDays());
    }

    friend ostream& operator<<(ostream &output, Date& date){
        //output << date.day << "/" << date.month << "/" << date.year;
        // output << daysOfWeek[ (date.findTotalDays() + date.startWeekDay) % 7 ];
        return output;
    }

};
const int Date::daysInMonths[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
const string Date::daysOfWeek[7] = {"Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"};
const string Date::monthsOfYear[] = { "", "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" };

int main() {
    // Crear dos fechas e imprimir
    Date date1(2,8,2014);
    Date date2(10,15,1944);
    cout<<"Fecha 1: "<<date1 <<endl;
    cout<<"Fecha 2: "<<date2 <<endl;

    // Crear dos fechas, incrementarlas e imprimirlas.
    Date date3 = date1;
    Date date4 = date2;
    date3++;
    date4++;
    cout<<"Fecha 3: "<<date3 << endl;
    cout<<"Fecha 4: "<<date4 << endl;

    // Sumar y eliminar dias a una fecha
    date3+=20;
    date4-=130;
    cout<<"Fecha 3 add 20: "<<date3 << endl;
    cout<<"Fecha 4 sub 130: "<<date4 << endl;

    // Encontrar la diferencia de días entre dos fechas
    cout<<"Diferencia entre las fechas 3 y 4 son "<< date3 - date4 << " dias";
    return 0;
}

