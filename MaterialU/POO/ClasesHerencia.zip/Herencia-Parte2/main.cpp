#include <iostream>

using namespace std;

class Vehiculo{
public:
    string placa;
protected:
    float cilindraje;
    string chasis;
public:
    Vehiculo(): placa(""), cilindraje(0.0), chasis(""){
    }
    Vehiculo(string placa, float cilindraje, string chasis)
                        : placa(placa), cilindraje(cilindraje), chasis(chasis) {}

    const string &getPlaca() const {
        return placa;
    }

    void setPlaca(const string &placa) {
        Vehiculo::placa = placa;
    }

    float getCilindraje() const {
        return cilindraje;
    }

    void setCilindraje(float cilindraje) {
        Vehiculo::cilindraje = cilindraje;
    }

    const string &getChasis() const {
        return chasis;
    }

    void setChasis(const string &chasis) {
        Vehiculo::chasis = chasis;
    }

};

class Carroceria : public Vehiculo{
private:
    string tipo;
    int cantidadPuertas;
public:
    Carroceria(): Vehiculo(), tipo(""), cantidadPuertas(0) {}
    Carroceria(string placa, float cilindraje, string chasis, string tipo, int cantidadPuertas)
                : Vehiculo(placa, cilindraje, chasis),
                tipo(tipo), cantidadPuertas(cantidadPuertas) {}

    const string &getTipo() const {
        return tipo;
    }

    void setTipo(const string &tipo) {
        Carroceria::tipo = tipo;
    }

    int getCantidadPuertas() const {
        return cantidadPuertas;
    }

    void setCantidadPuertas(int cantidadPuertas) {
        Carroceria::cantidadPuertas = cantidadPuertas;
    }
};

class Moto: public Vehiculo{
private:
    float cabrillaAncho, cabrillaLargo;
public:
    Moto(): Vehiculo(), cabrillaAncho(0.0), cabrillaLargo(0.0){}
    Moto(string placa, float cilindraje, string chasis, float cabrillaAncho, float cabrillaLargo)
            : Vehiculo(placa, cilindraje, chasis),
            cabrillaAncho(cabrillaAncho), cabrillaLargo(cabrillaLargo){}

    float getCabrillaAncho() const {
        return cabrillaAncho;
    }

    void setCabrillaAncho(float cabrillaAncho) {
        Moto::cabrillaAncho = cabrillaAncho;
    }

    float getCabrillaLargo() const {
        return cabrillaLargo;
    }

    void setCabrillaLargo(float cabrillaLargo) {
        Moto::cabrillaLargo = cabrillaLargo;
    }

    friend ostream& operator<<(ostream &output, Moto moto){
        output << "Informacion de la moto" << endl;
        output << "Placa: " << moto.placa << endl;
        output << "Cilindraje: " << moto.cilindraje << endl;
        output << "Chasis: " << moto.chasis << endl;
        output << "Cabrilla ancho: " << moto.cabrillaAncho << endl;
        output << "Cabrilla largo: " << moto.cabrillaLargo << endl;
        return output;
    }

};

class Camion: public Carroceria{
private:
    float capacidadCarga;
public:
    Camion() : Carroceria(), capacidadCarga(0.0) {}
    Camion(string placa, float cilindraje, string chasis, string tipo,
           int cantidadPuertas, float capacidadCarga)
           : Carroceria(placa, cilindraje, chasis, tipo, cantidadPuertas),
           capacidadCarga(capacidadCarga) {}

    float getCapacidadCarga() const {
        return capacidadCarga;
    }

    void setCapacidadCarga(float capacidadCarga) {
        Camion::capacidadCarga = capacidadCarga;
    }

    friend ostream& operator<<(ostream &output, Camion camion){
        output << "Informacion del camion" << endl;
        output << "Placa: " << camion.placa << endl;
        output << "Cilindraje: " << camion.cilindraje << endl;
        output << "Chasis: " << camion.chasis << endl;
        output << "Tipo carroceria: " << camion.getTipo() << endl;
        output << "Cantidad puertas: " << camion.getCantidadPuertas() << endl;
        output << "Capacidad de carga: " << camion.capacidadCarga << endl;
        return output;
    }
};

class Automovil: public Carroceria{
private:
    bool baul;
public:
    Automovil() : Carroceria(), baul(false) {}
    Automovil(string placa, float cilindraje, string chasis, string tipo,
    int cantidadPuertas, bool baul)
    : Carroceria(placa, cilindraje, chasis, tipo, cantidadPuertas),
    baul(baul) {}

    bool getBaul() const {
        return baul;
    }

    void setBaul(bool baul) {
        Automovil::baul = baul;
    }

    friend ostream& operator<<(ostream &output, Automovil automovil){
        output << "Informacion del automovil" << endl;
        output << "Placa: " << automovil.placa << endl;
        output << "Cilindraje: " << automovil.cilindraje << endl;
        output << "Chasis: " << automovil.chasis << endl;
        output << "Tipo carroceria: " << automovil.getTipo() << endl;
        output << "Cantidad puertas: " << automovil.getCantidadPuertas() << endl;
        output << "Baul: " << automovil.baul << endl;
        return output;
    }
};

class Deportivo: public Automovil{
public:
    Deportivo() : Automovil() {}
    Deportivo(string placa, float cilindraje, string chasis, string tipo,
    int cantidadPuertas, bool baul)
    : Automovil(placa, cilindraje, chasis, tipo, cantidadPuertas, baul){}

    friend ostream& operator<<(ostream &output, Deportivo deportivo){
        output << "Informacion del deportivo" << endl;
        output << "Placa: " << deportivo.placa << endl;
        output << "Cilindraje: " << deportivo.cilindraje << endl;
        output << "Chasis: " << deportivo.chasis << endl;
        output << "Tipo carroceria: " << deportivo.getTipo() << endl;
        output << "Cantidad puertas: " << deportivo.getCantidadPuertas() << endl;
        output << "Baul: " << deportivo.getBaul()<< endl;
        return output;
    }
};

int main() {
    Camion camion("aaa", 3450, "aaaxx", "camion", 2, 5200);
    Automovil automovil("bbb", 1200, "qwerty", "sedan", 4, true);
    Deportivo deportivo("ccc", 4200, "zzzzz", "deportivo", 2, false);
    Moto moto("dddd", 125, "moto",100, 200);

    cout << camion <<endl;
    cout << automovil << endl;
    cout << deportivo << endl;
    cout << moto << endl;
    return 0;
}
