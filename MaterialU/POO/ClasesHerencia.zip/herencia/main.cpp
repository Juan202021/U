#include <iostream>

using namespace std;

class Persona{
private:
    string nombre;
    string apellido;
public:
    Persona(): nombre(""), apellido(""){}
    Persona(string nombre, string apellido): nombre(nombre), apellido(apellido){}

    const string &getNombre() const {
        return nombre;
    }

    void setNombre(const string &nombre) {
        Persona::nombre = nombre;
    }

    const string &getApellido() const {
        return apellido;
    }

    void setApellido(const string &apellido) {
        Persona::apellido = apellido;
    }
    friend ostream& operator<<(ostream &out, Persona persona){
        out << "Nombre: " << persona.nombre;
        out << "Apellido: " << persona.apellido;
    }
};

class Estudiante : public Persona{
    float promedio;
    string codigo;
public:
    Estudiante() : Persona(), promedio(0.0), codigo(""){}
    Estudiante(string nombre,
               string apellido,
               string codigo,
               float promedio) : Persona(nombre, apellido),
                                    codigo(codigo), promedio(promedio){
    }

    float getPromedio() const {
        return promedio;
    }

    void setPromedio(float promedio) {
        Estudiante::promedio = promedio;
    }

    const string &getCodigo() const {
        return codigo;
    }

    void setCodigo(const string &codigo) {
        Estudiante::codigo = codigo;
    }
    friend ostream& operator<<(ostream &out, Estudiante estudiante){
        out << "Nombre: " << estudiante.getNombre() << endl;
        out << "Apellido: " << estudiante.getApellido() << endl;
        out << "Codigo: " << estudiante.codigo << endl;
        out << "Promedio: " << estudiante.promedio << endl;
    }
};

class EstudiantePregrado: public Estudiante{

};

class Profesor: public Persona{

};

class Administrativo: public Persona {

};

int main() {
    Estudiante estudiante("Victor", "Jara", "16000", 3.7);
    cout << estudiante;

    cout << endl;
    Persona persona("Ali", "Primera");
    cout << persona;
    return 0;
}
